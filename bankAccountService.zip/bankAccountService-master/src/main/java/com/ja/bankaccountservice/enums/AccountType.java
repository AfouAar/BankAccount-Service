package com.ja.bankaccountservice.enums;

public enum AccountType {
    SAVING_ACCOUNT,
    CURRENT_ACCOUNT
}
